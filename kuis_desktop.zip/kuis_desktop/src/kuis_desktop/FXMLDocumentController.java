
package kuis_desktop;

import java.net.URL;
import java.util.ResourceBundle;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Button;
import javafx.scene.control.DatePicker;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;


public class FXMLDocumentController implements Initializable {
    
    @FXML
    private Label labelnama;
    
    @FXML
    private TextField tfnama;
    
    @FXML
    private Label labelnpm;
    
    @FXML
    private TextField tfnpm;
    
    @FXML
    private Label labeltanggal;
    
    @FXML
    private DatePicker datepick;
    
    @FXML
    private Label labelujian;
    
    @FXML
    private TextField tfujian;
    
    @FXML
    private Label labeldata;
    
    @FXML
    private TextField tfdata;
    
    @FXML
    private Button btnsave;
    
    @FXML
    private void handleButtonAction(ActionEvent event) {
        System.out.println("You clicked me!");
        System.out.println(tfnama.getText());
        System.out.println(tfnpm.getText());
    }
    
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        // TODO
    }    
    
}
