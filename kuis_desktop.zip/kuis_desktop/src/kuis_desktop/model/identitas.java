
package kuis_desktop.model;

/**
 *
 * @author Asus
 */
public class identitas {
    private String nama;
    private String npm;
    private String tanggal;
    private String ujian;
    private String data;
    
    public identitas (String nama, String npm, String tanggal, String ujian, String data) {
        this.nama = nama;
        this.npm = npm;
        this.tanggal = tanggal;
        this.ujian = ujian;
        this.data = data;
    }

    public void setNama(String nama) {
        this.nama = nama;
    }

    public void setNpm(String npm) {
        this.npm = npm;
    }

    public void setTanggal(String tanggal) {
        this.tanggal = tanggal;
    }

    public void setUjian(String ujian) {
        this.ujian = ujian;
    }

    public void setData(String data) {
        this.data = data;
    }

    public String getNama() {
        return nama;
    }

    public String getNpm() {
        return npm;
    }

    public String getTanggal() {
        return tanggal;
    }

    public String getUjian() {
        return ujian;
    }

    public String getData() {
        return data;
    }

}

