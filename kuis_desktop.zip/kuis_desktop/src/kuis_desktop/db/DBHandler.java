
package kuis_desktop.db;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.logging.Level;
import java.util.logging.Logger;
import kuis_desktop.model.identitas;

public class DBHandler {
    public final Connection conn;
    
    public DBHandler(String driver) {
        this.conn = DBHelper.getConnection(driver);
    }
    
    public void addidentitas (identitas its){
        String insertits = "INSERT INTO `identitas`(`nama`, `npm`, `tanggal`,`ujian`,`data`)"
                + "VALUES (?,?,?,?,?)";
        try {
            PreparedStatement stmtInsert = conn.prepareStatement(insertits);
            stmtInsert.setString(1, its.getNama());
            stmtInsert.setString(2, its.getNpm());
            stmtInsert.setString(3, its.getTanggal());
            stmtInsert.setString(4, its.getUjian());
            stmtInsert.setString(5, its.getData());
            stmtInsert.execute();
        } catch (SQLException ex) {
            Logger.getLogger(DBHandler.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
}
